
import { GoogleGenAI } from "@google/genai";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

export const analyzeIndustry = async (industry: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the digital landscape for the "${industry}" industry. 
    Explain why a strong digital identity is crucial for this sector. 
    Suggest which of these 3 design themes would be best for them and why:
    1. Prestij (Corporate & Authoritative)
    2. Aksiyon (Dynamic & Fast)
    3. Vizyon (Modern & Innovative)
    
    Provide the response in Turkish, keep it persuasive and professional.`,
    config: {
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
    }
  });

  return response.text;
};
